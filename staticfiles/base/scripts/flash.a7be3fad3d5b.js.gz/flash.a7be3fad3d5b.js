$(document).ready(function () {
    // Removes flash messages after N seconds (10 here)
    // function closeFlash() {
    //     let flashContainer = $(".flash-container");
    //     // Check if flashContainer is displayed as block
    //     if (flashContainer.css('display') === 'block') {
    //         setTimeout(function() {
    //             flashContainer.fadeOut(300);
    //         }, 10000);
    //     }
    // }
    // closeFlash();
    $('.close-flash').click(function () {
        $('.flash-container').fadeOut(300);
    });
});
